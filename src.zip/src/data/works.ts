import type { Entry } from "./types";

export const works: Entry[] = [
  {
    id: "inu1",
    title: "Works1",
    description: "概要",
    images: ["/images/inu1.jpg", "/images/inu2.png"],
    body: "説明"
  },
  {
    id: "inu2",
    title: "Works2",
    description: "概要",
    images: ["/images/inu3.jpg", "/images/inu4.jpg"],
    body: "説明"
  }
];