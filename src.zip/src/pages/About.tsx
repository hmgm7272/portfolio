import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faXTwitter } from "@fortawesome/free-brands-svg-icons";

export default function About() {
    return (
        <div>
            <h1>About</h1>
            <div className="wrapper">
                <img></img>
                <div className="sentence">
                    <h2>はまがみ ゆうき</h2>
                    <span>連絡先</span>
                    <FontAwesomeIcon icon={faXTwitter} size="2x" />
                </div>
            </div>
        </div>
    )
}